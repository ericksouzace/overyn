fn main() {
    forgeloop_lib::run();
}
